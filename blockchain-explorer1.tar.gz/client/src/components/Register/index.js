/**
 *    SPDX-License-Identifier: Apache-2.0
 */

import Register from './Register';

export default Register;
