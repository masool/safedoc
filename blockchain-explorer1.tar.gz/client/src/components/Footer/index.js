// SPDX-License-Identifier: Apache-2.0

import FooterView from './FooterView';

export default FooterView;
