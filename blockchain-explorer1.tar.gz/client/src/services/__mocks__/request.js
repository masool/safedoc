/**
 *    SPDX-License-Identifier: Apache-2.0
 */

// TODO add request mocks
const countHeader = {
  chaincodeCount: 1,
  txCount: 10,
  latestBlock: 5,
  peerCount: 1,
};
